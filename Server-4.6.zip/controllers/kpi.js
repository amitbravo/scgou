const {connectionPool} = require('../util/snowflake')
const mysqlConnection = require('../util/connection.js')
const Excel = require('exceljs');
const  nodemailer = require('nodemailer');
const moment = require('moment')
const _ = require('lodash')



const testSnowflakeConnection = (clientConnection)=> {
  console.log({ connectionStatus: clientConnection.isUp() , connectionId: clientConnection.getId() })
}

const validText = async(req, res)=> {
  // THIS IS FOR suggestions >  sqlText: `select DISTINCT ${searchType} from SFPTEITMLTST.PTEITMLKPI.PARAMETRIC_TEST;`,
  // select * from SFPTEITMLTST.PTEITMLKPI.PARAMETRIC_TEST_VW where ${searchType} = ${searchText}
  var searchText = req.query.searchText //cob
  var searchType = req.query.searchType //TEST_TYPE, TEST_NAME , TEST_NUMBER

  console.log('searchText',searchText,'searchType',searchType)

  connectionPool.use(async (clientConnection) =>
  {
    console.log(clientConnection.isUp())
    const statement = await clientConnection.execute({
    sqlText: `select * from SFPTEITMLTST.PTEITMLKPI.PARAMETRIC_TEST where ${searchType} = '${searchText}';`,

        complete: function (err, stmt, rows)
        {
            if(err){
                console.log('err to call ',err)
                return res.send({ status: true }) //yeah true, that means if true ,.. let it type ..
            } else {
              console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
              console.log('rows',rows)
              return res.send({ status: rows.length > 0 ? true : false })
            }
        }
    });
  })
}


const suggestions = async(req, res)=> {

  // THIS IS FOR suggestions >  sqlText: `select DISTINCT ${searchType} from SFPTEITMLTST.PTEITMLKPI.PARAMETRIC_TEST;`,

  // select * from SFPTEITMLTST.PTEITMLKPI.PARAMETRIC_TEST_VW where ${searchType} = ${searchText}

  var searchText = req.query.searchText //cob
  var searchType = req.query.searchType //TEST_TYPE, TEST_NAME , TEST_NUMBER

  console.log('searchText',searchText,'searchType',searchType)

  connectionPool.use(async (clientConnection) =>
  {
    //console.log('clientConnection',clientConnection)
    console.log(clientConnection.isUp())
    const statement = await clientConnection.execute({
    sqlText: `select DISTINCT ${searchType} from SFPTEITMLTST.PTEITMLKPI.PARAMETRIC_TEST;`,

        complete: function (err, stmt, rows)
        {

            if(err){
                console.log('err to call ',err)
                return res.send({ status: false })
            } else {
              console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
              console.log('rows',rows)
              return res.send({ status: true, data: rows })
            }
        }
    });
  })
}



const search_kpi =  async(req, res)=> {
      console.log('req',req.query)
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
      console.log('offset',offset)
      var search = String(req.query.search).trim()
      if(search.length < 1){
        res.send({ status: true, data: [] })
      }
      var queryInit = `select * from KPI_CONFIG_GSHEELAM where `
      var query = ''

      if(req.query.search_type == 'ALL'){
        //console.log('internal')
        query = ` 'KPI_ID = '${search}' or PROJECT = '${search}' or OPERATION = '${search}' or FOUNDRY = '${search}' or TEST_NAME = '${search}' or TEST_NUMBER = '${search}' or TEST_TYPE = '${search}' or UNIQUE_GEN_KPI_CONFIG_ID = '${search}' ORDER BY KPI_CONFIG_ID DESC  `
      } else {
        query = ` ${req.query.search_type} = '${search}'   `
      }

    //var count_query = `select count(*) as count from KPI_CONFIG where ${query} `
    var count_query = `select * from KPI_CONFIG_GSHEELAM where ${query} `

    var finalQuery = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
    console.log('countqueyr',count_query)
    connectionPool.use(async (clientConnection) =>
    {
      console.log('clientConnection',clientConnection)
      console.log(clientConnection.isUp(), req.body)
      const statement = await clientConnection.execute({
      sqlText: finalQuery,

          complete: async function (err, stmt, rows)
          {

              if(err){
                  console.log('err to call ',err)
                  return res.send({ status: false })
              } else {
                console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
                //console.log('rows',rows)
                try {
                  const total_count = await total_count_function(clientConnection, count_query)
                  console.log('total_count',total_count)
                  return res.send({status: true, data: rows, count: rows.length, total_count })
                } catch (error){
                    console.log('did not get')
                    return res.send({status: true, data: rows, count: rows.length, total_count: 0 })
                }
              }
          }
      });
    })
}

function total_count_function (clientConnection, query){
  console.log('query',query)
  return new Promise((resolve, reject) => {
      clientConnection.execute({
      sqlText: query,
      complete: function (err, stmt, rows)
      {
          if(err){
              console.log('err to get row length',err,query)
              return reject(0);
          } else {
            console.log('get rows: ' + stmt.getSqlText() + ' > ' + rows.length)
            return resolve(rows.length)
          }
      }
      });
  })
}


const search_kpi_extended =  async (req, res)=> {

      console.log('req>>>',req.query)
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0

      var search_any = String(req.query.search_any).trim()
	  var KPI_ID = String(req.query.kpi_id).trim()
      var PROJECT = String(req.query.project).trim()
      var OPERATION = String(req.query.operation).trim()
      var FOUNDRY = String(req.query.foundry).trim()
      var TEST_NAME = String(req.query.test_name).trim()
      var TEST_NUMBER = String(req.query.test_number).trim()
      var TEST_TYPE = String(req.query.test_type).trim()
      var UNIQUE_GEN_KPI_CONFIG_ID = String(req.query.unique_gen_kpi_config_id).trim()


      //console.log('ww',file_seq_id.length)

      // if(search_any.length < 1 && loh_lot_id.length < 1 && facility.length < 1 && operation.length < 1 && lot_id.length < 1 && correlation_id.length < 1  && file_id.length < 1 && lot_status.length < 1 && error_cause.length < 1 ){
      //   res.send({ status: true, data: [], count: 0 })
      //   return
      // }

      var queryInit = `select * from KPI_CONFIG_GSHEELAM where `
      var query =  ''

      // if(search_any.length > 0) {
      //   //console.log('second style',search_any.length)
      //   query = ` PROJECT = '${search_any}' or OPERATION = '${search_any}' or FOUNDRY = '${search_any}' or TEST_NAME = '${search_any}' or TEST_NUMBER = '${search_any}' or TEST_TYPE = '${search_any}' or UNIQUE_GEN_KPI_CONFIG_ID = '${search_any}'  `
      //   var countquery = `select count(*) as count from KPI_CONFIG where ${query} `
      //   query = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
      //
      //
      //
      //   console.log('final query1',query)
      //   mysqlConnection.query(query, (err, rows, fields) => {
      //       if(!err){
      //         res.send({status: true, data: rows, count: rows.length, total_count  })
      //       }
      //       else {
      //         console.log(err)
      //
      //       }
      //   })
      // } else

      if(KPI_ID.length > 0 || PROJECT.length > 0 ||  OPERATION.length > 0 ||  FOUNDRY.length > 0 ||  TEST_NAME.length > 0 ||  TEST_NUMBER.length > 0  || TEST_TYPE.length > 0 ||  UNIQUE_GEN_KPI_CONFIG_ID.length > 0  ){
          //console.log('third style')
          var atleastone = 0
		  if(KPI_ID.length > 0){
            atleastone = 1
            query = ` KPI_ID = '${KPI_ID}' `
          }
          if(PROJECT.length > 0){
            atleastone = 1
            query = ` PROJECT = '${PROJECT}' `
          }

          if(OPERATION.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} OPERATION = '${OPERATION}' `
          }

          if(FOUNDRY.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} FOUNDRY = '${FOUNDRY}' `
          }

          if(TEST_NAME.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} TEST_NAME = '${TEST_NAME}' `
          }

          if(TEST_NUMBER.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} TEST_NUMBER = '${TEST_NUMBER}' `
          }

          if(TEST_TYPE.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} TEST_TYPE = '${TEST_TYPE}' `
          }

          if(UNIQUE_GEN_KPI_CONFIG_ID.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} UNIQUE_GEN_KPI_CONFIG_ID = '${UNIQUE_GEN_KPI_CONFIG_ID}' `
          }

          console.log('query222',query)

          //var count_query = `select count(*) as count from KPI_CONFIG where ${query} `
          var count_query = `select * from KPI_CONFIG_GSHEELAM where ${query} ORDER BY KPI_CONFIG_ID DESC`
          var finalQuery = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
          console.log('count_query',count_query)

          connectionPool.use(async (clientConnection) =>
          {
            console.log('clientConnection',clientConnection)
            console.log(clientConnection.isUp(), req.body)
            const statement = await clientConnection.execute({
            sqlText: finalQuery,

                complete: async function (err, stmt, rows)
                {

                    if(err){
                        console.log('err to call ',err)
                        return res.send({ status: false })
                    } else {
                      console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
                      //console.log('rows',rows)
                      try {
                        const total_count = await total_count_function(clientConnection, count_query)
                        console.log('total_count',total_count)
                        return res.send({status: true, data: rows, count: rows.length, total_count })
                      } catch (error){
                          console.log('did not get')
                          return res.send({status: true, data: rows, count: rows.length, total_count: 0 })
                      }
                    }
                }
            });
          })

          // try {
          //   const rows = await awaitquery(count_query);
          //   console.log('rows count x',rows[0].count);
          //   total_count = rows[0].count
          // } catch(error) {
          //   console.log('error',error)
          //   //conn.end();
          // }

          // mysqlConnection.query(`SELECT COUNT(*) FROM loh_lot where ${query}`, (err, rows, fields) => {
          //     if(!err){
          //       console.log('rows count',rows)
          //     }
          //     else {
          //       console.log(err)
          //     }
          // })

          // query = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
          // console.log('final query xxxx',query)
          // mysqlConnection.query(query, (err, rows, fields) => {
          //     if(!err){
          //       console.log('rows',rows)
          //       res.send({status: true, data: rows, count: rows.length, total_count })
          //     }
          //     else {
          //       console.log(err)
          //     }
          // })

        }





    //res.send({ status: true })
    // var row_id = req.body.id;
    // //var

}


const kpitest = async (req, res)=> {
    try {
       var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
       console.log('offset',offset)
       var limit = (typeof req.query !== 'undefined' && typeof req.query.limit !== 'undefined') ?  req.query.limit : 20
        console.log('limit', limit)
        let thequery = `SELECT * FROM kpi_config LIMIT ${limit} OFFSET ${offset}`
        mysqlConnection.query(thequery, (err, rows, fields) => {
            if(!err){
              console.log('rows',rows.length)
              //res.send({data: rows, status: true,})
              res.send({data: rows, error: false })
            }
            else {
              console.log(err)
              res.send({ data: [], error: true, err })
            }
        })
      }
      catch (error) {
        console.log('error',error)
        res.send({ data: [], error: true })
      }

}


const kpi = async (req, res)=> {
    // try {
       var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
    //   //console.log('offset',offset)
      var limit = (typeof req.query !== 'undefined' && typeof req.query.limit !== 'undefined') ?  req.query.limit : 20
    //   console.log('limit', limit)
    //   let thequery = `SELECT * FROM kpi_config LIMIT ${limit} OFFSET ${offset}`
    //   mysqlConnection.query(thequery, (err, rows, fields) => {
    //       if(!err){
    //         console.log('rows',rows.length)
    //         //res.send({data: rows, status: true,})
    //         res.send({data: rows, error: false })
    //       }
    //       else {
    //         console.log(err)
    //         res.send({ data: [], error: true, err })
    //       }
    //   })
    // }
    // catch (error) {
    //   console.log('error',error)
    //   res.send({ data: [], error: true })
    // }

    connectionPool.use(async (clientConnection) =>
    {
      //console.log('clientConnection',clientConnection)
      //console.log(clientConnection.isUp(), req.body)
      testSnowflakeConnection(clientConnection)
      const statement = await clientConnection.execute({
      sqlText: `select * from SFPTEITMLTST.PTEITMLKPI.KPI_CONFIG ORDER BY KPI_CONFIG_ID DESC LIMIT ${limit} OFFSET ${offset};`,

          complete: function (err, stmt, rows)
          {

              if(err){
                  console.log('err to call ',err)
                  return res.send({ status: false })
              } else {
                console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
                console.log('rows',rows)
                return res.send({ status: true, data: rows })
              }
          }
      });
    })


}


const validate1 =  async (req, res) => {
  // 1. connect snowflake
  // 2. call the procedure ...
  // 3. -> call P_KPI_CONFIG_UPLOAD_VALIDATION()
  // 33.. get back the response
  // 4. i get the date from tmp table .. give back to the client ...
  //I
  //2. get data from validateion

  var tableName = req.body.tableName
  //var tableName = 'YMSOPERATIONS.YMS.KPI_STAGE_GOUTHAM_1649341064'
  //console.log('tableName',tableName)

  connectionPool.use(async (clientConnection) =>
  {
    //console.log('clientConnection',clientConnection)
    //var newTable = 'demo'
    console.log(clientConnection.isUp(), req.body)
    testSnowflakeConnection(clientConnection)


    //return;
    const statement = await clientConnection.execute({
    sqlText: `call P_KPI_CONFIG_UPLOAD_VALIDATION1('${tableName}');`,

        complete: function (err, stmt, rows)
        {

            if(err){
                console.log('err to call ',err)
                return res.send({ status: false })
            } else {
              console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
              if(String(stmt.getSqlText()).indexOf('Failed: Code') > -1){
                return res.send({status: false })
              }

              return clientConnection.execute({
                  sqlText: `select PROJECT, OPERATION, FOUNDRY, TEST_NAME, TEST_NUMBER, TEST_TYPE, PSEUDO_NAME, KPI_LEVEL1, KPI_LEVEL2, KPI_LEVEL3, CATEGORY, CS_PERFORMANCE, SPEC, TARGET, VERSION_ID, LATEST_FLAG, ACTIVATION_DATE, DEACTIVATION_DATE, HPL, LPL, ROW_SPEC, TT_TARGET, SS_SPEC, SPEC_TYPE, VALIDATION_STATUS, ERROR from ${tableName} `,
                  complete: function (err2, stmt2, rows2)
                  {

                      console.log('rows2',rows2)
                      //console.log(rows2)

                      if(err2){
                        return res.send({ status: false, err })
                      } else {
                        console.log('get rows',rows2)
                        return res.send({ status: true, msg: 'all_worked', data: rows2 })
                        //console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
                      }

                      // var stream = statement2.streamRows();
                      // stream.on('data', function (row)
                      // {
                      //     console.log(row);
                      // });
                      // stream.on('end', function (row)
                      // {
                      //     console.log('All rows consumed');
                      // });
                  }
              });
              //return res.send({ status: true })
            }

            // var stream = statement.streamRows();
            // stream.on('data', function (row)
            // {
            //     console.log(row);
            // });
            // stream.on('end', function (row)
            // {
            //     console.log('All rows consumed');
            // });
        }
    });
  })
}

async function validate1_extension (clientConnection, newTable) {
  //console.log('run2')
  const statement2 = await clientConnection.execute({
      sqlText: `insert into ${newTable} (PROJECT,OPERATION,FOUNDRY,TEST_NAME,TEST_NUMBER,TEST_TYPE,PSEUDO_NAME,KPI_LEVEL1,KPI_LEVEL2,KPI_LEVEL3,CATEGORY,CS_PERFORMANCE,SPEC,TARGET,VERSION_ID,LATEST_FLAG,ACTIVATION_DATE,
                                                  DEACTIVATION_DATE,HPL,LPL,LOADED_DATE,ROW_SPEC,TT_TARGET,SS_SPEC,SPEC_TYPE)
      values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      binds: newData,

      complete: function (err, stmt, rows)
      {

          if(err){
            return { status: false, err }
          } else {

            //console.log('Done Yaar')
            return { status: true, msg: 'all_worked'}
            //console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
          }

          // var stream = statement2.streamRows();
          // stream.on('data', function (row)
          // {
          //     console.log(row);
          // });
          // stream.on('end', function (row)
          // {
          //     console.log('All rows consumed');
          // });
      }
  });
}

const validate2 = async (req, res) => {
  // 1. connect snowflake
  // 2. call the procedure ...
  // 3. -> call P_KPI_CONFIG_UPLOAD_VALIDATION()
  // 33.. get back the response
  // 4. i get the date from tmp table .. give back to the client ...
  //I
  //2. get data from validateion

  var tableName = req.body.tableName
  var currentUser = req.body.currentUser
  //var tableName = 'YMSOPERATIONS.YMS.KPI_STAGE_GOUTHAM_1649341064'
  //console.log('tableName',tableName)

  connectionPool.use(async (clientConnection) =>
  {
    //console.log('clientConnection',clientConnection)
    //var newTable = 'demo'
    console.log(clientConnection.isUp(), req.body)
    testSnowflakeConnection(clientConnection)


    //return;
    const statement = await clientConnection.execute({
    sqlText: `call P_KPI_CONFIG_UPLOAD_INSERT('${tableName}');`,

        complete: function (err, stmt, rows)
        {
           console.log('Printing the rows..', rows,stmt,err)
            if(err){
                console.log('err to call ',err)
				console.log('Printing the error..', err)
                return res.send({ status: false })
            } else {
              console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
              if(String(stmt.getSqlText()).indexOf('Failed: Code') > -1){
                return res.send({status: false })
              }
              //trigger a function...
              mail_extension(clientConnection,tableName,currentUser)
              return res.send({ status: true,rows })


            }

            // var stream = statement.streamRows();
            // stream.on('data', function (row)
            // {
            //     console.log(row);
            // });
            // stream.on('end', function (row)
            // {
            //     console.log('All rows consumed');
            // });
        }
    });
  })

}


const upload_kpi = async (req, res)=> {
    //console.log('req',req.body)
    //console.clear();
    //console.log('req7',req.body.tableName, typeof(req.body.data), req.body.data )
    var x = req.body.data
    //var columns = req.body.columns

    console.log('old>>',x)
    var d = new Date()
    var newData =   _.map(x, (eachArray, index) => {
         eachArray.splice(20,0,d)
         return eachArray
     })
     console.log('newData',newData)



    var newTable = req.body.tableName
    //console.log('newTable',newTable)
    //newTable = ` YMSOPERATIONS.YMS.KPI_STAGE_${newTable} `
    //console.log('newTable2',newTable)

    //var newTable = ' YMSOPERATIONS.YMS.KPI_STAGE_GOUTHAM_1649255292 '

    //return res.send({ status: true })
    //return;

    connectionPool.use(async (clientConnection) =>
    {
      //console.log('clientConnection',clientConnection)
      //var newTable = 'demo'
      console.log(clientConnection.isUp(),clientConnection)
      testSnowflakeConnection(clientConnection)
      //return;
      const statement = await clientConnection.execute({
      sqlText: `create or replace  TABLE ${newTable} (
	TEMP_ID NUMBER(38,0) NOT NULL autoincrement,
	PROJECT VARCHAR(45) ,
	OPERATION VARCHAR(45) ,
	FOUNDRY VARCHAR(45),
	TEST_NAME VARCHAR(250) ,
	TEST_NUMBER VARCHAR(100) ,
	TEST_TYPE VARCHAR(100),
	PSEUDO_NAME VARCHAR(250),
	KPI_LEVEL1 VARCHAR(45),
	KPI_LEVEL2 VARCHAR(45),
	KPI_LEVEL3 VARCHAR(45),
	CATEGORY VARCHAR(45) ,
	CS_PERFORMANCE VARCHAR(45),
	SPEC VARCHAR(45),
	TARGET VARCHAR(45),
	VERSION_ID VARCHAR(45) ,
	LATEST_FLAG VARCHAR(45),
	ACTIVATION_DATE VARCHAR(45),
	DEACTIVATION_DATE VARCHAR(45),
	HPL VARCHAR(45),
	LPL VARCHAR(45),
	CREATE_DATE TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	CREATEDBY VARCHAR(45) NOT NULL DEFAULT 'SYSTEM',
	UPDATE_DATE TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	UPDATEDBY VARCHAR(45) NOT NULL DEFAULT 'SYSTEM',
	UNIQUE_GEN_KPI_CONFIG_ID VARCHAR(100),
	TRANSACT_SEQ VARCHAR(50),
	LOADED_DATE TIMESTAMP_NTZ(9),
	ROW_SPEC VARCHAR(45),
	TT_TARGET VARCHAR(45),
	SS_SPEC VARCHAR(45),
	SPEC_TYPE VARCHAR(10),
	VALIDATION_STATUS VARCHAR(50),
	ERROR VARCHAR(250),
	unique (UNIQUE_GEN_KPI_CONFIG_ID),
	primary key (TEMP_ID)
);`,

          complete: function (err, stmt, rows)
          {

              if(err){
                  console.log('err to create table',err)
                  return res.send({ status: false, err })
              } else {
                console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
                run2(clientConnection, newData, newTable)
                return res.send({ status: true, msg: 'hey' })
              }

              // var stream = statement.streamRows();
              // stream.on('data', function (row)
              // {
              //     console.log(row);
              // });
              // stream.on('end', function (row)
              // {
              //     console.log('All rows consumed');
              // });

          }
      });

      //return
      //2. insert data
      //thequery,req.body.data
      //return;
      //console.log('adding data now',newData.length, newData[0].length)
      //return;
      //return;



      // connection.execute({
      //   sqlText: 'insert into ${newTable}(PROJECT, OPERATION) values(?, ?)',
      //   binds: [[1, 'string1'], [2, 'string2'], [3, 'string3']]
      // });


    });

    //return res.send({ status: true })

    //1. connect to snowflake ---
    //1. now I create a tmp on the snowflake --- 13123123_gautam_
  //   create or replace temporary TABLE kpi_stage_gsheelam_03272022 (
	// TEMP_ID NUMBER(38,0) NOT NULL autoincrement,
	// PROJECT VARCHAR(45) NOT NULL,
	// OPERATION VARCHAR(45) NOT NULL,
	// FOUNDRY VARCHAR(45),
	// TEST_NAME VARCHAR(250) NOT NULL,
	// TEST_NUMBER VARCHAR(100) NOT NULL,
	// TEST_TYPE VARCHAR(100),
	// PSEUDO_NAME VARCHAR(250),
	// KPI_LEVEL1 VARCHAR(45),
	// KPI_LEVEL2 VARCHAR(45),
	// KPI_LEVEL3 VARCHAR(45),
	// CATEGORY VARCHAR(45) NOT NULL,
	// CS_PERFORMANCE VARCHAR(45),
	// SPEC VARCHAR(45),
	// TARGET VARCHAR(45),
	// VERSION_ID VARCHAR(45) NOT NULL,
	// LATEST_FLAG NUMBER(38,0) NOT NULL,
	// ACTIVATION_DATE TIMESTAMP_NTZ(9),
	// DEACTIVATION_DATE TIMESTAMP_NTZ(9),
	// HPL FLOAT,
	// LPL FLOAT,
	// CREATE_DATE TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	// CREATEDBY VARCHAR(45) NOT NULL DEFAULT 'SYSTEM',
	// UPDATE_DATE TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	// UPDATEDBY VARCHAR(45) NOT NULL DEFAULT 'SYSTEM',
	// UNIQUE_GEN_KPI_CONFIG_ID VARCHAR(100),
	// TRANSACT_SEQ VARCHAR(50),
	// LOADED_DATE TIMESTAMP_NTZ(9),
	// ROW_SPEC FLOAT,
	// TT_TARGET FLOAT,
	// SS_SPEC FLOAT,
	// SPEC_TYPE VARCHAR(10),
  // VALIDATION_STATUS VARCHAR(50),
  //ERROR VARCHAR(250),
	//unique (UNIQUE_GEN_KPI_CONFIG_ID),
	//primary key (TEMP_ID)
//);

//3. insert something like this >>

// insert into pteitmlkpi.kpi_stage_gsheelam_03272022(project,operation,foundry,test_name,test_number,test_type,pseudo_name,kpi_level1,kpi_level2,kpi_level3,category,cs_performance,spec,target,version_id,latest_flag,activation_date,
//                                                   deactivation_date,hpl,lpl,unique_gen_kpi_config_id,transact_seq,loaded_date,row_spec,tt_target,ss_spec,spec_type,validation_status,error) values
//                                                   ('PALIMA_MEP','FT1','TSMC','Main.FN_APSSLOCALCPRHT_NOM.CPU_FUSE_BIN1_HT.PerModeDatalog[GOLDP__BOOSTP].CPR_Guardband',8368100,'P','FT1_PALIMA_MEP_TSMC_P_8368100_Main.FN_APSSLOCALCPRHT_NOM.CPU_FUSE_BIN1_HT.PerModeDatalog[GOLDP__BOOSTP].CPR_Guardband',
//                                           'CPR','L3(V)','TURL3','',0.724,0.95,1,1,1,'2021-12-26 00:00:00.000',NULL,1.052000046,0.8560000062,'0e5a6bcd5c79dca993b84cdfb8be845c',20220305203141000000000004267867217,'2022-03-05 13:00:20.960',0.95,NULL,NULL,'High',NULL,NULL);

//

  //4.
  //  return res.send({ status: true, status_msg: 'step1' })

    // try {
    //     var datetime = moment().format('YYYY-MM-DD HH:mm:ss.000')
    //     //const onboard_audit_query = "INSERT INTO `ml_project_onboard_audit` (`id`, `system`, `resource`, `action`, `action_detail`, `updated_query`, `updated_row_count`, `action_timestamp_utc`, `action_status`, `performed_by`) VALUES (?,?,?,?,?,?,?,?,?,?) "
    //     const thequery = "INSERT INTO `ml_project_onboard_audit` (`id`, `system`, `resource`, `action`, `action_detail`, `updated_query`, `updated_row_count`, `action_timestamp_utc`, `action_status`, `performed_by`) VALUES ? "
    //     mysqlConnection.query(thequery,req.body.data, (err, rows, fields) => {
    //         if(!err){
    //           console.log('rows',rows.length)
    //           //res.send({data: rows, status: true,})
    //           res.send({data: rows.length, error: false,  status: true, status_msg: 'step1' })
    //         }
    //         else {
    //           console.log(err)
    //           res.send({ data: [], error: true, err, status: false, status_msg: 'step1' })
    //         }
    //     })
    //     // var query = ''
    //     // for (const item of req.body.data){
    //     //     console.log('item',item)
    //     //
    //     // }
    //   }
    //   catch (error) {
    //     console.log('error',error)
    //     res.send({ error: true })
    //   }

}

async function run2 (clientConnection, newData, newTable) {
  console.log('run2',clientConnection, newData, newTable)
  const statement2 = await clientConnection.execute({
      sqlText: `insert into ${newTable} (PROJECT,OPERATION,FOUNDRY,TEST_NAME,TEST_NUMBER,TEST_TYPE,PSEUDO_NAME,KPI_LEVEL1,KPI_LEVEL2,KPI_LEVEL3,CATEGORY,CS_PERFORMANCE,SPEC,TARGET,VERSION_ID,LATEST_FLAG,ACTIVATION_DATE,
                                                  DEACTIVATION_DATE,HPL,LPL,LOADED_DATE,ROW_SPEC,TT_TARGET,SS_SPEC,SPEC_TYPE)
      values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      binds: newData,

      complete: function (err, stmt, rows)
      {

          if(err){
            console.log('err',err)
            return { status: false, err }
          } else {

            console.log('run2: Done')
            return { status: true, msg: 'all_worked'}
            //console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
          }

          // var stream = statement2.streamRows();
          // stream.on('data', function (row)
          // {
          //     console.log(row);
          // });
          // stream.on('end', function (row)
          // {
          //     console.log('All rows consumed');
          // });
      }
  });
}


const update_multi_kpi = (req, res)=> {
    //var datetime = moment().format('YYYY-MM-DD HH:mm:ss.000')
	var datetime = moment().utc().format('YYYY-MM-DD HH:mm:ss.000')
    //console.log('update_multi_kpi starts')
    var query = ''

    //console.log('req.body.data',req.body.data)
    //return
    connectionPool.use(async (clientConnection) =>
    {
      //console.log('clientConnection',clientConnection)
      //console.log(clientConnection.isUp(), req.body)
      var totalRows = req.body.data
      var i = 0
    for (const item of totalRows){
      i++
      //console.log('each',each)
	  //console.log('iteration:' , i);
      //query += mysql.format("UPDATE tabletest SET users = ? WHERE id = ?; ", item);
      //query +=  mysql.format("update loh_lot set lot_status = ?, error_cause = ? where loh_lot_id = ?; ",item)
	  console.log('totalRows:', totalRows);
      var query2 = ''
      var atleastone = false

      if(typeof item.KPI_LEVEL1 !== 'undefined'){
        atleastone = true
        query2 = ` KPI_LEVEL1 = '${item.KPI_LEVEL1}' `
      }
      if(typeof item.KPI_LEVEL2 !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} KPI_LEVEL2 = '${item.KPI_LEVEL2}' `
      }
      if(typeof item.KPI_LEVEL3 !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} KPI_LEVEL3 = '${item.KPI_LEVEL3}' `
      }

      if(typeof item.TEST_NAME !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} TEST_NAME = '${item.TEST_NAME}' `
      }

	  if(typeof item.TEST_NUMBER !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} TEST_NUMBER = '${item.TEST_NUMBER}' `
      }

	  if(typeof item.TEST_TYPE !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} TEST_TYPE = '${item.TEST_TYPE}' `
      }

	  if(typeof item.CATEGORY !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} CATEGORY = '${item.CATEGORY}' `
      }

      if(typeof item.CS_PERFORMANCE !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} CS_PERFORMANCE = '${item.CS_PERFORMANCE}' `
      }

   /*   if(typeof item.ACTIVATION_DATE !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} ACTIVATION_DATE = '${item.ACTIVATION_DATE}' `
      }

	  if(typeof item.DEACTIVATION_DATE !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} DEACTIVATION_DATE = '${item.DEACTIVATION_DATE}' `
      }

	  if(typeof item.HPL !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} HPL = '${item.HPL}' `
      }

	  if(typeof item.LPL !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} LPL = '${item.LPL}' `
      } */

	  if(typeof item.ROW_SPEC !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} ROW_SPEC = '${item.ROW_SPEC}' `
      }

	  if(typeof item.TT_TARGET !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} TT_TARGET = '${item.TT_TARGET}' `
      }

	  if(typeof item.SS_SPEC !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} SS_SPEC = '${item.SS_SPEC}' `
      }

	  if(typeof item.SPEC_TYPE !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} SPEC_TYPE = '${item.SPEC_TYPE}' `
      }

      //console.log('query2 formation',query2)
      //query +=  mysql.format(` update KPI_CONFIG set ${query2} where KPI_CONFIG_ID = '${item.KPI_CONFIG_ID}'; `)
      query = ` update KPI_CONFIG_GSHEELAM set ${query2} , update_date = '${datetime}', updatedby = '${req.body.currentUser}' where KPI_CONFIG_ID = '${item.KPI_CONFIG_ID}'; `


    }
    //console.log('query>>>',query)

    //return;

      const statement = await clientConnection.execute({
      sqlText: query,

          complete: async function (err, stmt, rows)
          {

              if(err){
                  console.log('err to call ',err)
                  return res.send({ status: false, error: true })
              } else {
                console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
                console.log(i,totalRows.length)
                if(i === totalRows.length){
                  return res.send({ status: true, error: false })
                }
                //return res.send({ status: true, error: false })
              }
          }
      });

	  //}

    })


    //console.log('query',query)
    // try {
    //   mysqlConnection.query(query, (err, rows, fields) => {
    //       if(!err){
    //         mysqlConnection.query(onboard_audit_query, [null, 'ML Data Ops UI', 'DE Control', 'update', 'updated DE Control table', String(query), Object.keys(req.body.data).length, datetime, 'Success', String(req.body.currentUser)], (err2, rows2, fields2) => {
    //             if(!err2){
    //               console.log('')
    //             } else {
    //               console.log('problem to log activity',err2)
    //             }
    //         })
    //         res.send({status: true, error: false })
    //       }
    //       else {
    //         console.log(err)
    //         res.send({status: false, error: true })
    //       }
    //   })
    // } catch (error) {
    //   res.send({status: false, error: true })
    // }
    //
    // //res.send({ status: true })

}

async function mail_extension(clientConnection,tableName,currentUser){
  console.log('triggering mail_extension tableName',tableName)
  const statement = await clientConnection.execute({
  sqlText: ` select * from ${tableName}  `,

      complete: async function (err, stmt, rows)
      {

          if(err){
              console.log('err to call ',err)
              return { status: false, error: true }
          } else {
            console.log('Successfully got data for mail: ' + stmt.getSqlText() + ' > ' + rows.length)
            try {
              var get = await sendMail(rows,currentUser)
            } catch (e) {

            } finally {

            }
            console.log('email sending status',get)
            return { status: true, error: false }
          }
      }
  });
}

async function sendMail(data,currentUser){
    console.log('data to send',data,currentUser)
  //return;
    const filename = `kpidata_${moment().format('DD-MM-YYYY')}_report.xlsx`;
    let workbook = new Excel.Workbook();
    let worksheet = workbook.addWorksheet('Sheet1');
    var headerArray = []
    _.map(data[0], (each, eachColumn) => {
      headerArray.push({ header: eachColumn, key: eachColumn })
    })
    console.log('headerArray',headerArray)
    worksheet.columns = headerArray


    // if(data.length === 0 ){
    //
    //   worksheet.columns = [
    //       {header: 'First Name', key: 'firstName'},
    //       {header: 'Last Name', key: 'lastName'},
    //       {header: 'Purchase Price', key: 'purchasePrice'},
    //       {header: 'Payments Made', key: 'paymentsMade'},
    //   ];
    //
    //   data = [
    //       {
    //           firstName: 'John',
    //           lastName: 'Bailey',
    //           purchasePrice: 1000,
    //           paymentsMade: 100,
    //       },
    //       {
    //           firstName: 'Leonard',
    //           lastName: 'Clark',
    //           purchasePrice: 1000,
    //           paymentsMade: 150,
    //       },
    //   ];
    // }
    data.forEach((e) => {
        worksheet.addRow(e);
    });
    const buffer = await workbook.xlsx.writeBuffer();
    //var fromEmail = 'vjchve@gmail.com'
	var fromEmail = 'gsheelam@qualcomm.com'
    const transporter = nodemailer.createTransport({
        host: 'smtphost.qualcomm.com',
        port: '25',
        secure: false,
        //auth: {
        //    user: fromEmail,

       // },
        //tls: {
        //ciphers:'SSLv3'
       // }
	   logger: true,
	debug: false,
	pool: true,
	maxConnections: 1
    });
    const mailOptions = {
            from: fromEmail,
            to: 'gsheelam@qualcomm.com',
            subject: 'KPI Report',
            html: 'content',
            attachments: [
                {
                    filename,
                    content: buffer,
                    contentType:
                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                },
            ],
     };
    var status = await transporter.sendMail(mailOptions);
    console.log('status',status.response)
    if(status.response){
      return true;
    }
    else {
      return false;
    }
}




module.exports = {
    validText,
    suggestions,
    search_kpi,
    search_kpi_extended,
    kpitest,
    kpi,
    validate1,
    validate2,
    upload_kpi,
    update_multi_kpi,
}
