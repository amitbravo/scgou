const db = {
    account: process.env.DB_SNOWFLAKE_ACCOUNT,
    username: process.env.DB_SNOWFLAKE_USERNAME,
    password: process.env.DB_SNOWFLAKE_PASSWORD,
    database: process.env.DB_SNOWFLAKE_DATABASE,
    //warehouse: process.env.SF_WAREHOUSE, --Amitbravo i disabled it for now
    schema: process.env.DB_SNOWFLAKE_SCHEMA,
    // role: process.env.SF_ROLE
};
const pool_size = {
  max: 10, // specifies the maximum number of connections in the pool
  min: 0,  // specifies the minimum number of connections in the pool
  testOnBorrow: true, // Validate connection before acquiring it
  acquireTimeoutMillis: 60000, // Timeout to acquire connection
  evictionRunIntervalMillis: 900000, // Check every 15 min for ideal connection
  numTestsPerEvictionRun: 4, // Check only 4 connections every 15 min
  idleTimeoutMillis: 10800000, // Evict only if connection is ideal for 3 hrs
  clientSessionKeepAlive: true
}
const port = process.env.HTTP_PORT || 8080;
const node_env =
  process.env.NODE_ENV == "production" || process.env.NODE_ENV == "prd"
    ? "production"
    : "dev";

module.exports = {
  db,
  pool_size,
  port,
  node_env,
};
