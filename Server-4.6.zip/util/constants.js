exports.ApiConstants = {
    OperatorMap : {
        "EQUALS" : "=",
        "NOT_EQUALS" : "!=",
        "GREATER" : ">",
        "NOT_GREATER" : "!>",
        "LESS" : "<",
        "NOT_LESS" : "!<",
        "GREATER_EQUALS" : ">=",
        "LESSER_EQUALS" : "<=",
        "IN":"IN",
        "NOT_IN":"NOT IN",
        "LIKE":"LIKE",
        "NOT_LIKE":"NOT LIKE",
        "STARTS_WITH":"STARTS_WITH"
    },
    DataTypes :{
        "STRING": "STRING",
        "DATE": "DATE",
        "DATETIME" : "DATETIME",
        "NUMBER": "NUMBER"
    }
    }