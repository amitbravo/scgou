const path = require('path')
const appRoot = require('app-root-path');
require('dotenv').config({path: appRoot + path.sep + ".env"});
console.log('process.env.DB_HOST',process.env.DB_HOST, process.env.DB_USER, process.env.DB_PASSWORD, process.env.DB_DATABASE)
var mysql = require('mysql');

const config = {
    databaseOptions: {
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_DATABASE,
        multipleStatements: true
    }
}

// ENVIRONMENT LOADS
//var env = process.env.NODE_ENV.trim();
var host = process.env.DB_HOST;
var user = process.env.DB_USER;
var password = process.env.DB_PASSWORD;
var database = process.env.DB_DATABASE;
//var port = process.env.MYSQL_PORT.trim();



let mysqlConnection = null; // db handler
let connected = null; // default null / boolean
let connectFreq = 1000; // When database is disconnected, how often to attempt reconnect? Miliseconds
let testFreq = 5000; // After database is connected, how often to test connection is still good? Miliseconds

function attemptMySQLConnection(callback) {
  console.log('attemptMySQLConnection')
  if (host && user && database) {

    mysqlConnection = mysql.createPool(config.databaseOptions);

    testConnection((result) => {
      callback(result)
    })

  } else {
    console.error('Check env variables: MYSQL_HOST, MYSQL_USER & MYSQL_DB')
    callback(false)
  }
}

function testConnection(cb) {
  console.log('testConnection')
  mysqlConnection.query('SELECT * userlevel', (error, results, fields) => {

    try {
      if (error) {
        throw new Error('No DB Connection');
      } else {
        console.log('yup')
        // if (results[0].solution) {
        //   cb(true)
        // } else {
        //   cb(false)
        // }
        cb(true)
      }
    } catch (e) {
      // console.error(e.name + ': ' + e.message);
      cb(false)
    }
  });
}

function callbackCheckLogic(res) {
  if (res) {
    console.log('Connect was good. Scheduling next test for ', testFreq, 'ms')
    setTimeout(testConnectionCB, testFreq);
  } else {
    console.log('Connection was bad. Scheduling connection attempt for ', connectFreq, 'ms')
    setTimeout(connectMySQL, connectFreq);
  }
}

function testConnectionCB() {
  testConnection((result) => {
    callbackCheckLogic(result);
  })
}

function connectMySQL() {
  attemptMySQLConnection(result => {
    callbackCheckLogic(result);
  });
}

connectMySQL(); // Start the process by calling this once

module.exports = mysqlConnection;
