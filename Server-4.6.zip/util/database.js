const dbConfig = require("../config/appConfig");
//const log = require("js-logger")(__filename);
// const errors = require("js-errors");
const snowflake = require('snowflake-sdk');
const genericPool = require("generic-pool");

const factory = {
    create: () => {
        return new Promise((resolve, reject) => {
            // Create Connection
            const connection = snowflake.createConnection(dbConfig.db);
            // Try to connect to Snowflake, and check whether the connection was successful.
            connection.connect((err, conn) => {
                if (err) {
                    console.log('Unable to connect: ' + err.message);
                    reject(new Error(err.message));
                } else {
                    console.log('Successfully connected to Snowflake, ID:', conn.getId());
                    resolve(conn);
                }
            });
        });
    },
    destroy: (connection) => {
        return new Promise((resolve, reject) => {
            resolve()
            connection.destroy((err, conn) => {
                if (err) {
                    //log.error('Unable to disconnect: ' + err.message);
                } else {
                    //log.info('Disconnected connection with id: ' + conn.getId());
                }
                resolve(); // Always resolve for destroy
            });
        });
    },
    validate: (connection) => {
        return new Promise((resolve, reject) => {
            resolve(connection.isUp());
        });
    }
};

const opts = {
    max: 12, // Maximum size of the pool
    min: 3, // Minimum size of the pool,
    testOnBorrow: true, // Validate connection before acquiring it
    acquireTimeoutMillis: 600000, // Timeout to acquire connection
    evictionRunIntervalMillis: 900000, // Check every 15 min for ideal connection
    numTestsPerEvictionRun: 4, // Check only 4 connections every 15 min
    idleTimeoutMillis: 10800000, // Evict only if connection is ideal for 3 hrs
    clientSessionKeepAlive: true
};

const myPool = genericPool.createPool(factory, opts);

module.exports = {
  myPool
};
