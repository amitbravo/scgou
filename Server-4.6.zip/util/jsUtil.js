const updateObject = async (oldObject, updatedProperties) => {
  return {
    ...oldObject,
    ...updatedProperties,
  };
};
const format = text => {
  return text
    .toUpperCase()
    .replace(/\s/g, "-")
    .replace(/_/g, "-")
    .replace(/[^a-zA-Z0-9-]/g, "")
    .replace(/-+/g, "-");
};

const camelToSnakeCaseKeys = o => {
  if (isObject(o)) {
    const n = {};

    Object.keys(o).forEach(k => {
      n[camelToSnakeCase(k)] = camelToSnakeCaseKeys(o[k]);
    });

    return n;
  } else if (isArray(o)) {
    return o.map(i => {
      return camelToSnakeCaseKeys(i);
    });
  }

  return o;
};

const camelToSnakeCase = str => {
  return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
};

const toCamelCase = text => {
  text = text
    .toLowerCase()
    .replace(/[-_\s.]+(.)?/g, (_, c) => (c ? c.toUpperCase() : ""));
  return text.substr(0, 1).toLowerCase() + text.substr(1);
  // return text.toLowerCase()
  //     .replace(/['"]/g, '')
  //     .replace(/\W+/g, ' ')
  //     .replace(/ (.)/g, function($1) { return $1.toUpperCase(); })
  //     .replace(/ /g, '');
};

const isArray = arr => {
  return Array.isArray(arr);
};

const isObject = obj => {
  return obj === Object(obj) && !isArray(obj) && typeof obj !== "function";
};

const camelCaseKeys = o => {
  if (isObject(o)) {
    const n = {};

    Object.keys(o).forEach(k => {
      n[toCamelCase(k)] = camelCaseKeys(o[k]);
    });

    return n;
  } else if (isArray(o)) {
    return o.map(i => {
      return camelCaseKeys(i);
    });
  }

  return o;
};

module.exports = {
  isObject,
  isArray,
  camelCaseKeys,
  updateObject,
  format,
  camelToSnakeCaseKeys,
  camelToSnakeCase,
  toCamelCase,
};
