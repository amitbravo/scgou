var express = require('express')
const bodyparser = require('body-parser')
const cors = require('cors')
const fs = require('fs')
const util = require('util');

const mysqlConnection = require('./util/connection.js')
const mysqlConnection2 = require('./util/connection2.js')

const moment = require('moment')
const _ = require('lodash')
const axios = require('axios')
//var snowflake = require('snowflake-sdk');

const unlinkFile = util.promisify(fs.unlink)
const multer = require('multer')
const upload = multer({ dest: 'uploads/' })
var multerType = upload.single("myFile")
const { uploadFile, getFileStream } = require('./util/s3')

//const sf_pool = require("./util/database")
//const connectionPool = sf_pool.myPool

const router  = express.Router();
const { validText,
suggestions,
search_kpi,
search_kpi_extended,
kpitest,
kpi,
validate1,
validate2,
upload_kpi,
update_multi_kpi } = require('./controllers/kpi')


app = express()
port = process.env.PORT || 8000;
app.use(bodyparser.urlencoded({limit: '10mb', extended: true}))
app.use(bodyparser.json({limit: '10mb', extended: true}))
app.use(cors())


const awaitquery = util.promisify(mysqlConnection.query).bind(mysqlConnection);

//   const connectionPool = snowflake.createPool(
//     // connection options
//     {
//       account: 'EI60496.europe-west4.gcp',
// 	    username:'BILLUBRAVO',
// 	    password:'YVGKQ@b7qyx',
//       database: 'SFPTEITMLTST',
//       //warehouse: 'PTEITML_LOAD_XS_WH',
//       schema: 'PTEITMLKPI',
//     },
//     // pool options
//     {
//       max: 10, // specifies the maximum number of connections in the pool
//       min: 0,   // specifies the minimum number of connections in the pool
//       acquireTimeoutMillis: 60000, // Timeout to acquire connection
//       evictionRunIntervalMillis: 900000, // Check every 15 min for ideal connection
//       numTestsPerEvictionRun: 4, // Check only 4 connections every 15 min
//       idleTimeoutMillis: 10800000, // Evict only if connection is ideal for 3 hrs
//       clientSessionKeepAlive: true
//     }
// );






app.get('/project_onboarding', async (req, res)=> {
    try {
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
      var limit = (typeof req.query !== 'undefined' && typeof req.query.limit !== 'undefined') ?  req.query.limit : 20

      //console.log('offset',offset)

      let thequery = `SELECT * FROM ml_project_onboard_control LIMIT ${limit} OFFSET ${offset}`
      mysqlConnection2.query(thequery, (err, rows, fields) => {
          if(!err){
            console.log('rows',rows.length)
            //res.send({data: rows, status: true,})
            res.send({data: rows, error: false })
          }
          else {
            console.log('errX',err)
            res.send({ data: [], error: true })
          }
      })
    }
    catch (error) {
      console.log('errorX',error)
      res.send({ data: [], error: true })
    }
})

app.post('/update_multi_project_onboarding', (req, res)=> {
    //var datetime = moment().format('YYYY-MM-DD HH:mm:ss.000')
    //console.log('update_multi_kpi starts')
    console.log('req',req.body)
    var query = ''
    var totalRows = req.body.data
    var i = 0
    for (const item of totalRows){
      i++
      var query2 = ''
      var atleastone = false

      if(typeof item.enable_ml_config !== 'undefined'){
        atleastone = true
        query2 = ` enable_ml_config = '${item.enable_ml_config}' `
      }
      if(typeof item.enable_pipeline_config !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} enable_pipeline_config = '${item.enable_pipeline_config}' `
      }
      if(typeof item.enable_sql_filter !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} enable_sql_filter = '${item.enable_sql_filter}' `
      }
      query +=  mysql.format(`update ml_project_onboard_control set ${query2} where id = '${item.id}'; `)

    }
    //query = ` update ml_project_onboard_control set ${query2} where id = '${item.id}'; `
    console.log('query to update',query)
    try {
      mysqlConnection2.query(query, (err, rows, fields) => {
          if(!err){
            res.send({status: true, error: false })
          }
          else {
            console.log(err)
            res.send({status: false, error: true })
          }
      })
    } catch (error) {
      res.send({status: false, error: true })
    }
})




app.get('/lohlot', async (req, res)=> {
    try {
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
      //console.log('offset',offset)
      let thequery = `SELECT * FROM loh_lot order by loh_lot_id desc LIMIT ${req.query.limit} OFFSET ${offset}`
      mysqlConnection.query(thequery, (err, rows, fields) => {
          if(!err){
            console.log('rows',rows.length)
            //res.send({data: rows, status: true,})
            res.send({data: rows, error: false })
          }
          else {
            console.log(err)
            res.send({ data: [], error: true })
          }
      })
    }
    catch (error) {
      console.log('error',error)
      res.send({ data: [], error: true })
    }
})


// error handled , step1 done,
app.post('/update_lohlot', (req, res)=> {
    try {
      mysqlConnection.query(`update loh_lot set lot_status='${req.body.lot_status}', error_cause='${req.body.error_cause}',updated_date='${datetime}',updatedby='${req.body.currentUser}' where loh_lot_id=${req.body.id}`, (err, rows, fields) => {
          if(!err){
            //console.log('rows',rows)
            res.send({status: true, error: false })
          }
          else {
            //console.log(err)
            res.send({ status: false, error: true })
          }
      })
    }
    catch (error) {
      console.log('error',error)
      res.send({ status: false, error: true })
    }
})


app.post('/update_multi_lohlot', (req, res)=> {

  try {
      var datetime = moment().utc().format('YYYY-MM-DD HH:mm:ss.000')
      const onboard_audit_query = "INSERT INTO `ml_project_onboard_audit` (`id`, `system`, `resource`, `action`, `action_detail`, `updated_query`, `updated_row_count`, `action_timestamp_utc`, `action_status`, `performed_by`) VALUES (?,?,?,?,?,?,?,?,?,?) "
      var query = ''
      for (const item of req.body.data){
        //console.log('each',each)
        //query += mysql.format("UPDATE tabletest SET users = ? WHERE id = ?; ", item);
        //query +=  mysql.format("update loh_lot set lot_status = ?, error_cause = ? where loh_lot_id = ?; ",item)
        var query2 = ''
        var atleastone = false
        if(typeof item.lot_status !== 'undefined'){
          atleastone = true
          query2 = ` lot_status = '${item.lot_status}' `
        }
        if(typeof item.error_cause !== 'undefined'){
          if (atleastone){
            query2 = ` ${query2} , `
          }
          query2 = ` ${query2} error_cause = '${item.error_cause}' `
        }
        //console.log('query2 formation',query2)
        query +=  mysql.format(`update loh_lot set ${query2},updated_date='${datetime}',updatedby='${req.body.currentUser}' where loh_lot_id = '${item.loh_lot_id}'; `)
      }
      console.log('all query',query)
      mysqlConnection.query(query, (err, rows, fields) => {
          if(!err){
            //console.log('rows',rows)
            mysqlConnection.query(onboard_audit_query, [null, 'ML Data Ops UI', 'LOH', 'update', 'updated LOH table', String(query), Object.keys(req.body.data).length, datetime, 'Success', String(req.body.currentUser)], (err2, rows2, fields2) => {
                if(!err2){
                  //res.send({status: true, error: false  })
                } else {
                  //res.send({status: false, error: true  })
                }
            })
            res.send({status: true, error: false })
          }
          else {
            console.log(err)
            res.send({status: false, error: true  })
          }
      })
  } catch(error){
    res.send({status: false, error: true  })
  }

  // //var query = `update loh_lot set  lot_status = 'JOB COMPLETEDX'  ,  error_cause = '' ,updated_date='2022-05-16 14:49:12.000',updatedby='goutham.maestro@gmail.com' where loh_lot_id = '748'; update loh_lot set  lot_status = 'JOB COMPLETEDX'  ,  error_cause = '' ,updated_date='2022-05-16 14:49:12.000',updatedby='goutham.maestro@gmail.com' where loh_lot_id = '747';`
  //
  // console.log('query',query)
  // mysqlConnection.query(query, (err, rows, fields) => {
  //    if(err){
  //      console.log('err',err)
  //      return res.send({ status: false })
  //    }
  //    else {
  //      console.log('no err')
  //      return res.send({ status: true })
  //    }
  // })

})




app.get('/search_lohlot_extended', async (req, res)=> {

      console.log('req.query',req.query)

      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0

      var search_any = String(req.query.search_any).trim()
      var loh_lot_id = typeof req.query.loh_lot_id !== 'undefined' ? String(req.query.loh_lot_id).trim() : ''
      var facility = typeof req.query.facility !== 'undefined' ? String(req.query.facility).trim() : ''
      var operation = typeof req.query.operation !== 'undefined' ? String(req.query.operation).trim() : ''
      var lot_id = typeof req.query.lot_id !== 'undefined' ? String(req.query.lot_id).trim() : ''
      var correlation_id = typeof req.query.correlation_id !== 'undefined' ? String(req.query.correlation_id).trim() : ''
      var file_id = typeof req.query.file_id !== 'undefined' ? String(req.query.file_id).trim() : ''
      var lot_status = typeof req.query.lot_status !== 'undefined' ?  String(req.query.lot_status).trim() : ''
      var error_cause = typeof req.query.error_cause !== 'undefined' ? String(req.query.error_cause).trim() : ''
      var project = typeof req.query.project !== 'undefined' ? String(req.query.project).trim(): ''

      // if(search_any.length < 1 && loh_lot_id.length < 1 && facility.length < 1 && operation.length < 1 && lot_id.length < 1 && correlation_id.length < 1  && file_id.length < 1 && lot_status.length < 1 && error_cause.length < 1 ){
      //   res.send({ status: true, data: [], count: 0 })
      //   return
      // }

      var queryInit = `select * from loh_lot where `
      var query =  ''
      if(search_any.length > 0) {
        //console.log('second style',search_any.length)
        query = ` loh_lot_id = '${search_any}' or facility = '${search_any}' or operation = '${search_any}' or lot_id = '${search_any}' or correlation_id = '${search_any}' or file_id = '${search_any}' or lot_status = '${search_any}' or error_cause = '${search_any}' or project = '${search_any}' `
        //console.log('query1',query)
        var total_count = 0
        try {
          const rows = await awaitquery(`select count(*) as count from loh_lot where ${query} `);
          //console.log('rows count x',rows[0].count,rows.count);
          total_count = rows[0].count
        } catch(error) {
          console.log('error',error)
          //conn.end();
        }

        query = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`

        console.log('query2',query)
        try {
          mysqlConnection.query(query, (err, rows, fields) => {
              if(!err){
                //console.log('rows results',total_count)
                res.send({status: true, error: false, data: rows, count: rows.length, total_count  })
              }
              else {
                console.log(err)
                res.send({status: false, error: true  })
              }
          })
        }
        catch(error){
            res.send({status: false, error: true  })
        }

      } else if(loh_lot_id.length > 0 ||  facility.length > 0 ||  operation.length > 0 ||  lot_id.length > 0 ||  correlation_id.length > 0  || file_id.length > 0 ||  lot_status.length > 0 ||  error_cause.length > 0 || project.length > 0){
          //console.log('third style')
          var atleastone = 0
          if(loh_lot_id.length > 0){
            atleastone = 1
            query = ` loh_lot_id = '${loh_lot_id}' `
          }

          if(facility.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} facility = '${facility}' `
          }

          if(operation.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} operation = '${operation}' `
          }

          if(lot_id.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} lot_id = '${lot_id}' `
          }

          if(correlation_id.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} correlation_id = '${correlation_id}' `
          }

          if(file_id.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} file_id = '${file_id}' `
          }

          if(lot_status.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} lot_status = '${lot_status}' `
          }

          if(error_cause.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} error_cause = '${error_cause}' `
          }

          if(project.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} project = '${project}' `
          }

          var total_count = 0
          var count_query = `select count(*) as count from loh_lot where ${query} `
          //console.log('count_query',count_query)
          try {
            const rows = await awaitquery(count_query);
            //console.log('rows count x',rows[0].count);
            total_count = rows[0].count
          } catch(error) {
            console.log('error',error)
            //conn.end();
          }

          // mysqlConnection.query(`SELECT COUNT(*) FROM loh_lot where ${query}`, (err, rows, fields) => {
          //     if(!err){
          //       console.log('rows count',rows)
          //     }
          //     else {
          //       console.log(err)
          //     }
          // })

          query = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
          console.log('query 333',query)
          try {
            mysqlConnection.query(query, (err, rows, fields) => {
                if(!err){
                  console.log('rows',rows)
                  res.send({status: true, error: false, data: rows, count: rows.length, total_count })
                }
                else {
                  console.log(err)
                  res.send({ status: false, error: true })
                }
            })
          } catch (error) {
              res.send({ status: false, error: true })
          }


        }





    //res.send({ status: true })
    // var row_id = req.body.id;
    // //var

})

app.get('/search_lohlot', async(req, res)=> {
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0

      var search = String(req.query.search).trim()
      if(search.length < 1){
        res.send({ status: true, data: [] })
      }
      var queryInit = `select * from loh_lot where `
      var query = ''

        // if all is selected
        if(req.query.search_type == 'all'){
          query = ` loh_lot_id = '${search}' or facility = '${search}' or operation = '${search}' or project = '${search}' or lot_id = '${search}' or correlation_id = '${search}' or file_id = '${search}' or lot_status = '${search}' or error_cause = '${search}'  `
        }
        else {
          query = ` ${req.query.search_type} = '${search}'   `
        }

        var total_count = 0
        try {
          const rows = await awaitquery(`select count(*) as count from loh_lot where ${query} `);
          //console.log('rows count x',rows[0].count,rows.count);
          total_count = rows[0].count
        } catch(error) {
          console.log('error',error)
          //conn.end();
        }


    query =  `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
    try {
      mysqlConnection.query(query, (err, rows, fields) => {
          if(!err){
            //console.log('rows',rows)
            res.send({status: true, error: false, data: rows, count: rows.length, total_count })
          }
          else {
            console.log(err)
            res.send({status: false, error: true })
          }
      })
    } catch(error){
      res.send({status: false, error: true })
    }

})



app.get('/decontrol', (req, res)=> {
  try {
    var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
    mysqlConnection.query(`SELECT * FROM de_control_table order by file_seq_id desc LIMIT ${req.query.limit} OFFSET ${offset}`, (err, rows, fields) => {
        if(!err){
          //console.log('rows',rows)
          //res.send({data: rows, status: true,})
          res.send({data: rows, status: true, error: false })
        }
        else {
          console.log(err)
          res.send({ status: false, error: true })
        }
    })
  } catch(error){
    res.send({ status: false, error: true })
  }

})

app.post('/update_multi_decontrol', (req, res)=> {
    var datetime = moment().utc().format('YYYY-MM-DD HH:mm:ss.000')
    const onboard_audit_query = "INSERT INTO `ml_project_onboard_audit` (`id`, `system`, `resource`, `action`, `action_detail`, `updated_query`, `updated_row_count`, `action_timestamp_utc`, `action_status`, `performed_by`) VALUES (?,?,?,?,?,?,?,?,?,?) "
    var query = ''
    for (const item of req.body.data){
      //console.log('each',each)
      //query += mysql.format("UPDATE tabletest SET users = ? WHERE id = ?; ", item);
      //query +=  mysql.format("update loh_lot set lot_status = ?, error_cause = ? where loh_lot_id = ?; ",item)
      var query2 = ''
      var atleastone = false
      if(typeof item.status !== 'undefined'){
        atleastone = true
        query2 = ` status = '${item.status}' `
      }
      if(typeof item.validate_status !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} validate_status = '${item.validate_status}' `
      }
      if(typeof item.load_status !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} load_status = '${item.load_status}' `
      }
      if(typeof item.transform_status !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} transform_status = '${item.transform_status}' `
      }
      if(typeof item.shell_status !== 'undefined'){
        if (atleastone){
          query2 = ` ${query2} , `
        }
        query2 = ` ${query2} shell_status = '${item.shell_status}' `
      }
      //console.log('query2 formation',query2)
      query +=  mysql.format(`update de_control_table set ${query2},update_date='${datetime}',updatedby='${req.body.currentUser}' where file_seq_id = '${item.file_seq_id}'; `)
    }
    //console.log('query',query)
    try {
      mysqlConnection.query(query, (err, rows, fields) => {
          if(!err){
            mysqlConnection.query(onboard_audit_query, [null, 'ML Data Ops UI', 'DE Control', 'update', 'updated DE Control table', String(query), Object.keys(req.body.data).length, datetime, 'Success', String(req.body.currentUser)], (err2, rows2, fields2) => {
                if(!err2){
                  console.log('')
                } else {
                  console.log('problem to log activity',err2)
                }
            })
            res.send({status: true, error: false })
          }
          else {
            console.log(err)
            res.send({status: false, error: true })
          }
      })
    } catch (error) {
      res.send({status: false, error: true })
    }

    //res.send({ status: true })

})


app.get('/search_decontrol_extended', async (req, res)=> {

      console.log('req>>>',req.query)
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0

      var search_any = String(req.query.search_any).trim()
      var file_seq_id = String(req.query.file_seq_id).trim()
      var file_type = String(req.query.file_type).trim()
      var project = String(req.query.project).trim()
      var operation = String(req.query.operation).trim()
      var lot = String(req.query.lot).trim()
      var wafername = String(req.query.wafername).trim()
      var src_file_id = String(req.query.src_file_id).trim()
      var correlationid = String(req.query.correlationid).trim()
      var status = String(req.query.status).trim()
      var data_type = String(req.query.data_type).trim()


      console.log('ww',file_seq_id.length)

      // if(search_any.length < 1 && loh_lot_id.length < 1 && facility.length < 1 && operation.length < 1 && lot_id.length < 1 && correlation_id.length < 1  && file_id.length < 1 && lot_status.length < 1 && error_cause.length < 1 ){
      //   res.send({ status: true, data: [], count: 0 })
      //   return
      // }

      var queryInit = `select * from de_control_table where `
      var query =  ''
      if(search_any.length > 0) {
        //console.log('second style',search_any.length)
        query = ` file_seq_id = '${search_any}' or file_type = '${search_any}' or project = '${search_any}' or operation = '${search_any}' or lot = '${search_any}' or wafername = '${search_any}' or src_file_id = '${search_any}' or correlationid = '${search_any}'  or status = '${status}' or data_type = '${data_type}' `
        var total_count = 0
        try {
          const rows = await awaitquery(`select count(*) as count from de_control_table where ${query} `);
          total_count = rows[0].count
        } catch(error) {
          console.log('error',error)
          //conn.end();
        }

        query = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`

        console.log('final query1',query)
        mysqlConnection.query(query, (err, rows, fields) => {
            if(!err){
              res.send({status: true, data: rows, count: rows.length, total_count  })
            }
            else {
              console.log(err)

            }
        })
      } else if(file_seq_id.length > 0 ||  file_type.length > 0 ||  project.length > 0 ||  operation.length > 0 ||  lot.length > 0  || wafername.length > 0 ||  src_file_id.length > 0 ||  correlationid.length > 0 || status.length > 0 || data_type.length > 0 ){
          //console.log('third style')
          var atleastone = 0
          if(file_seq_id.length > 0){
            atleastone = 1
            query = ` file_seq_id = '${file_seq_id}' `
          }

          if(file_type.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} file_type = '${file_type}' `
          }

          if(project.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} project = '${project}' `
          }

          if(operation.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} operation = '${operation}' `
          }

          if(lot.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} lot = '${lot}' `
          }

          if(wafername.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} wafername = '${wafername}' `
          }

          if(src_file_id.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} src_file_id = '${src_file_id}' `
          }

          if(correlationid.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} correlationid='${correlationid}' `
          }

          if(status.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} status='${status}' `
          }

          if(data_type.length > 0){
            if(atleastone == 1){
              query = `${query} and `
            }
            atleastone = 1
            query = `${query} data_type='${data_type}' `
          }

          console.log('query222',query)


          var total_count = 0
          var count_query = `select count(*) as count from de_control_table where ${query} `
          console.log('count_query',count_query)
          try {
            const rows = await awaitquery(count_query);
            console.log('rows count x',rows[0].count);
            total_count = rows[0].count
          } catch(error) {
            console.log('error',error)
            //conn.end();
          }

          // mysqlConnection.query(`SELECT COUNT(*) FROM loh_lot where ${query}`, (err, rows, fields) => {
          //     if(!err){
          //       console.log('rows count',rows)
          //     }
          //     else {
          //       console.log(err)
          //     }
          // })

          query = `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
          console.log('final query xxxx',query)
          mysqlConnection.query(query, (err, rows, fields) => {
              if(!err){
                console.log('rows',rows)
                res.send({status: true, data: rows, count: rows.length, total_count })
              }
              else {
                console.log(err)
              }
          })

        }





    //res.send({ status: true })
    // var row_id = req.body.id;
    // //var

})


app.get('/search_decontrol', async(req, res)=> {
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
      console.log('offset',offset)
      var search = String(req.query.search).trim()
      if(search.length < 1){
        res.send({ status: true, data: [] })
      }
      var queryInit = `select * from de_control_table where `
      var query = ''

      if(req.query.search_type == 'all'){
        //console.log('internal')
        query = ` file_seq_id = '${search}' or file_type = '${search}' or project = '${search}' or operation = '${search}' or lot = '${search}' or wafername = '${search}' or src_file_id = '${search}' or correlationid = '${search}' or status = '${search}' or data_type = '${search}'  `
      } else {
        query = ` ${req.query.search_type} = '${search}'   `
      }
    //res.send({ status: true })
    // var row_id = req.body.id;
    // //var
    //console.log('query',query)
    var total_count = 0
    try {
      const rows = await awaitquery(`select count(*) as count from de_control_table where ${query} `);
      //console.log('rows count x',rows[0].count,rows.count);
      total_count = rows[0].count
    } catch(error) {
      console.log('error',error)
      //conn.end();
    }

    query =  `${queryInit} ${query} LIMIT ${req.query.limit} OFFSET ${offset}`
    mysqlConnection.query(query, (err, rows, fields) => {
        if(!err){
          //console.log('rows',rows)
          res.send({status: true, data: rows, count: rows.length, total_count })
        }
        else {
          console.log(err)

        }
    })
})


//get all data from onboard_audit
app.get('/onboard_audit', (req, res)=> {
   var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0
   //console.log('offset',offset)
   mysqlConnection.query(`SELECT * FROM ml_project_onboard_audit order by id desc LIMIT ${req.query.limit} OFFSET ${offset}`, (err, rows, fields) => {
       if(!err){
         //console.log('rows',rows)
         //res.send({data: rows, status: true,})
         res.send(rows)
       }
       else {
         console.log(err)
       }
   })
})

app.get('/search_audit', async(req, res)=> {
      console.log('request',req.query)
      var offset = (typeof req.query !== 'undefined' && typeof req.query.offset !== 'undefined') ?  req.query.offset : 0

      var search = String(req.query.search).trim()
      // if(search.length < 1){
      //   res.send({ status: true, data: [] })
      // }

      var queryInit = `select * from ml_project_onboard_audit where `
      var query = ''
      var jointer = ' and '
      var jointer2 = ' '
      var flag = false


        // if all is selected
        if(req.query.search_type == 'all' && req.query.search !== ''){
          query = ` (performed_by = '${search}' or resource = '${search}') `
        }
        else if(req.query.search_type !== 'all' && req.query.search !== ''){
          query = ` ${req.query.search_type} = '${search}'   `
        }

        if(query === ''){
          jointer = ''
        }

        if(req.query.dateFrom_value !== ''){
          flag = true
          query = query +  ` ${jointer} action_timestamp_utc >=  '${req.query.dateFrom_value}'`
        }

        if(req.query.dateTo_value !== ''){
          if (flag){
            jointer = ' and '
          }
          query = query +  ` ${jointer} action_timestamp_utc <=  '${req.query.dateTo_value}'`
        }

        var total_count = 0
        try {
          const rows = await awaitquery(`select count(*) as count from ml_project_onboard_audit where ${query} `);
          //console.log('rows count x',rows[0].count,rows.count);
          total_count = rows[0].count
          console.log('total_count',total_count)
        } catch(error) {
          console.log('error',error)
          //conn.end();
        }


    query =  `${queryInit} ${query} ORDER BY action_timestamp_utc DESC LIMIT ${req.query.limit} OFFSET ${offset}`
    console.log('final > ',query)
    mysqlConnection.query(query, (err, rows, fields) => {
        if(!err){
          console.log('rows',rows.length)
          res.send({status: true, data: rows, count: rows.length, total_count })
        }
        else {
          console.log(err)
        }
    })
})


//api used when we edit a field
router.get('/validText', validText)
router.get('/suggestions', suggestions)
router.get('/search_kpi', search_kpi)
router.get('/search_kpi_extended', search_kpi_extended)
router.get('/kpitest', kpitest)
router.get('/kpi', kpi)
router.post('/validate1', validate1)
router.post('/validate2', validate2)
router.post('/upload_kpi', upload_kpi)
router.post('/update_multi_kpi', update_multi_kpi)
//router.get('/testSnowflakeConnection',testSnowflakeConnection)


app.get('/', async(req, res)=> {
  //console.log('request',req.query)
  //res.send({ status: true })
  return connectionPool.use(async (clientConnection) => {
    console.log('connectionPool',connectionPool)
    return res.send({ status: true, getId: clientConnection.getId() })
  })


})









//on kpi page ..
//app.get(....kpi_config of snowflake... )






//
// function extenion..(newtable){
//   //1. fetch data from tmp date
//   // 2. construct a csv file
//   // 3 we email to where...
//   // 4. sendgrid
// }



/*
app.post('/finalUpload', table){
  // 1. connect snowflake
  // 2. call the new procedure ...
  // 33.. reponse back
  // 4. i get back data from kpi_config .....
  //2. get data from validateion
}
*/


//1.


app.get('/userlevel', async (req, res)=> {
    //console.log('req',req.query)
    let thequery = `SELECT * FROM userlevel where username='${req.query.currentUser}' limit 1`
    mysqlConnection.query(thequery, (err, rows, fields) => {
        if(!err){
          console.log('rows',rows.length, rows)
          if(rows.length === 0){
            res.send({userlevel: { kpi: 0 }, status: true})
          }
           res.send({userlevel: rows, status: true,})
          //res.send({data: rows, error: false })
        }
        else {
          //console.log(err)
          //res.send({ data: [], error: true, err })
        }
    })
    //res.send({ status : true, userlevel: { kpi: true } })
})


// app.get('/', async (req, res)=> {
//   //res.send({ status : true })
//
//     //   var data = JSON.stringify({
//     // "advs": true,
//     // "mid": 0,
//     // "vid": 0,
//     // "sid": false,
//     // "cid": 6,
//     // "isc": true,
//     // "private": false,
//     // "country": "246",
//     // "state": "235",
//     // "pagenumber": 2,
//     // "orderby": 0
//     // });
//     //
//     // var config = {
//     // method: 'get',
//     // url: 'https://www.ventetid.no/api/product/search',
//     // headers: {
//     //   'Content-Type': 'application/json',
//     //   'Cookie': '.Nop.Customer=e939f530-49b2-4461-b1e5-c9b3d7871839; ARRAffinity=7be2be4124c4ec8738af13eccae702217e2302416495af2d224d8d30502456fe; ARRAffinitySameSite=7be2be4124c4ec8738af13eccae702217e2302416495af2d224d8d30502456fe'
//     // },
//     // data : data
//     // };
//     //
//     // axios(config)
//     // .then(function (response) {
//     // console.log(JSON.stringify(response.data));
//     // return response.data
//     // })
//     // .catch(function (error) {
//     // console.log('error to access',error);
//     // return { status: false, error }
//     // });
//
//
// })




app.post('/onboard_file_uploadfile', upload.single('myFile'), async (req, res) => {
  const file = req.file
  console.log(file)

  // apply filter
  // resize

  try {
    const result = await uploadFile(file)
    await unlinkFile(file.path)
    console.log(result)
    const description = `File uploaded at ${String(moment().unix())}`
    res.send({imagePath: `/images/${result.Key}` , status: true })
  }
  catch(error){
    console.log('fail to upload error',error)
    res.send({ status: false })
  }
})

app.use("/", router);
app.listen(port);
console.log('todo list RESTful API server started on: ' + port);
