const path = require('path')
const appRoot = require('app-root-path');
require('dotenv').config({path: appRoot + path.sep + ".env"});
console.log('process.env.DB_HOST',process.env.DB_HOST, process.env.DB_USER, process.env.DB_PASSWORD, process.env.DB_DATABASE)
const mysql = require('mysql')

// var mysqlConnection = mysql.createConnection({
//   port: 3306,
//   host: '127.0.0.1',
//   user: 'root',
//   password: 'password',
//   database: 'ymsoperations'
// })
//
//
// var mysqlConnection = mysql.createConnection({
//   host: process.env.DB_HOST,
//   user: process.env.DB_USER,
//   password: process.env.DB_PASSWORD, // Root@123456x
//   database: process.env.DB_DATABASE,
//   multipleStatements: true
// })

const config = {
    databaseOptions: {
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_DATABASE2,
        multipleStatements: true
    }
}

function handleError () {
  var mysqlConnection2  = mysql.createPool(config.databaseOptions);

    // Connection error, 2 seconds retry
    mysqlConnection2.getConnection(function (err, connection) {
        if (err) {
            console.log('error when connecting to db:', err);
            setTimeout(handleError , 2000);
        }
    });

    mysqlConnection2.on('connection', function (connection) {
      console.log('pool connected')
      //connection.query('SET SESSION auto_increment_increment=1')

      connection.on('error', function (err) {
        console.error(new Date(), 'MySQL error', err.code);
        //console.log('db error', err);
        // If the connection is disconnected, automatically reconnect
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            console.log('pool trying..')
            handleError();
        } else {
            throw err;
        }
      });

      connection.on('close', function (err) {
        console.error(new Date(), 'MySQL close', err);
      });


    });

    mysqlConnection2.on('acquire', function (connection) {
      console.log('pool Connection %d acquired', connection.threadId);
    });

    mysqlConnection2.on('enqueue', function () {
      console.log('pool Waiting for available connection slot');
    });

    mysqlConnection2.on('release', function (connection) {
      console.log('ppol Connection %d released', connection.threadId);
    });

    mysqlConnection2.on('error', function (err) {
        console.log('db error', err);
        // If the connection is disconnected, automatically reconnect
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            handleError();
        } else {
            throw err;
        }
    });

    return mysqlConnection2
}



module.exports = handleError();
