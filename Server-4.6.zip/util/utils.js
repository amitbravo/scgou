const prepareFilterClause = (filterRow) => {
    let filterClause = " ";
    if(filterRow.PROJECT){
      filterClause += " AND PROJECT='"+(filterRow.PROJECT).trim()+"'"
    }
    if(filterRow.KPI_LEVEL){
      filterClause += " AND KPI_LEVEL1='"+(filterRow.KPI_LEVEL).trim()+"'"
    }
    if(filterRow.OPERATION){
      let op = filterRow.OPERATION.toUpperCase()
      filterClause += " AND OPERATION ='"+(op).trim()+"'"
    }
    if(filterRow.X_PARAMETRIC_TEST_NAME){
      filterClause += " AND X_PARAMETRIC_TEST_NAME='"+(filterRow.X_PARAMETRIC_TEST_NAME).trim()+"'"
    }
    if(filterRow.CREATED_BY){
      let username = filterRow.CREATED_BY.toUpperCase()
      filterClause += " AND UPPER(CREATEDBY)='"+username.trim()+"'"
    }
    if(filterRow.CREATION_DATE_FROM && filterRow.CREATION_DATE_TO){
      filterClause += " AND CREATION_DATE BETWEEN to_date('"+filterRow.CREATION_DATE_FROM+"','YYYY/MM/DD') AND  to_date('"+filterRow.CREATION_DATE_TO+"','YYYY/MM/DD')"
    }else if(filterRow.CREATION_DATE_FROM){
      filterClause += " AND CREATION_DATE BETWEEN to_date('"+filterRow.CREATION_DATE_FROM+"','YYYY/MM/DD') AND TRUNC(SYSDATE)"
    }else if(filterRow.CREATION_DATE_TO){
      filterClause += " AND TRUNC(CREATION_DATE) <= to_date('"+filterRow.CREATION_DATE_TO+"','YYYY/MM/DD')"
    }
    filterClause += ' ORDER BY CREATE_DATE DESC'
    return filterClause;
  };

  


  module.exports = {
    prepareFilterClause: prepareFilterClause,
  }