var express = require('express')
const bodyparser = require('body-parser')
const cors = require('cors')
const fs = require('fs')
const util = require('util');

const snowflake = require('snowflake-sdk');

app = express()
port = process.env.PORT || 8000;
app.use(bodyparser.urlencoded({limit: '10mb', extended: true}))
app.use(bodyparser.json({limit: '10mb', extended: true}))
app.use(cors())

const dbConfig = require("./config/appConfig");

const connectionPool = snowflake.createPool(
  // connection options
  {
    account: 'EI60496.europe-west4.gcp',
    username:'BILLUBRAVO',
    password:'YVGKQ@b7qyx',
    database: 'SFPTEITMLTST',
    //warehouse: 'PTEITML_LOAD_XS_WH',
    schema: 'PTEITMLKPI',
  },
  // pool options
  {
    max: 10, // specifies the maximum number of connections in the pool
    min: 0,   // specifies the minimum number of connections in the pool
    acquireTimeoutMillis: 60000, // Timeout to acquire connection
    evictionRunIntervalMillis: 900000, // Check every 15 min for ideal connection
    numTestsPerEvictionRun: 4, // Check only 4 connections every 15 min
    idleTimeoutMillis: 10800000, // Evict only if connection is ideal for 3 hrs
    clientSessionKeepAlive: true
  }
);
// const sf_pool = require("./util/snowflake")
// const myPool = sf_pool.myPool
// const connectionPool = myPool.acquire();
//clientConnection



app.get('/createTable', async (req, res)=> {

  connectionPool.use(async (clientConnection) => {
    console.log('connection status: ',clientConnection.isUp(), clientConnection.getId())
    const statement = await clientConnection.execute({
    sqlText: `create or replace temporary TABLE demo (
    TEMP_ID NUMBER(38,0) NOT NULL autoincrement,
    PROJECT VARCHAR(45) ,
    primary key (TEMP_ID)
    );`,

      complete: function (err, stmt, rows)
      {

          if(err){
              console.log('err to create table',err)
              return res.send({ status: false, err })
          } else {
            console.log('Successfully executed statement: ' + stmt.getSqlText())
            return res.send({ status: true, err: false })
          }

          // var stream = statement.streamRows();
          // stream.on('data', function (row)
          // {
          //     console.log(row);
          // });
          // stream.on('end', function (row)
          // {
          //     console.log('All rows consumed');
          // });

      }
    })
  })
})

app.get('/getTable', async (req, res)=> {

  connectionPool.use(async (clientConnection) => {
    console.log('connection status: ',clientConnection.isUp(), clientConnection.getId())
    const statement = await clientConnection.execute({
    sqlText: `select * from SFPTEITMLTST.PTEITMLKPI.demo`,

      complete: function (err, stmt, rows)
      {
          if(err){
              console.log('err to create table',err)
              return res.send({ status: false, err })
          } else {
            console.log('Successfully executed statement: ' + stmt.getSqlText() + ' > ' + rows.length)
            return res.send({ status: true, err: false, rows })
          }

          // var stream = statement.streamRows();
          // stream.on('data', function (row)
          // {
          //     console.log(row);
          // });
          // stream.on('end', function (row)
          // {
          //     console.log('All rows consumed');
          // });

      }
    })
  })
})

app.get('/updateTable', async (req, res)=> {

  connectionPool.use(async (clientConnection) => {
    console.log('connection status: ',clientConnection.isUp(), clientConnection.getId())
    clientConnection.execute({
        sqlText: `insert into SFPTEITMLTST.PTEITMLKPI.demo (PROJECT) values(?)`,
        binds: ['DEMO'],
        complete: function (err, stmt, rows)
        {

            if(err){
              return res.send({ status: false, err })
            } else {
              return res.send({ status: true, err: false })
            }

            // var stream = statement2.streamRows();
            // stream.on('data', function (row)
            // {
            //     console.log(row);
            // });
            // stream.on('end', function (row)
            // {
            //     console.log('All rows consumed');
            // });
        }
    });
  })

})





app.listen(port);
console.log('todo list RESTful API server started on: ' + port);
