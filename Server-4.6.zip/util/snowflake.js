const dbConfig = require("../config/appConfig");
//const log = require("js-logger")(__filename);
// const errors = require("js-errors");
const snowflake = require('snowflake-sdk');

const connectionPool = snowflake.createPool(
  // connection options
  dbConfig.db,
  // pool options
  dbConfig.pool_size
);


module.exports = {
  connectionPool
};
